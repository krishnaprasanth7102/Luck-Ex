function getPreviewContent(url) {
    return new Promise((resolve, reject) => {
      fetch(url)
        .then(response => response.text())
        .then(data => {
         
          const title = data.match(/<title>(.*?)<\/title>/);
          const description = data.match(/<meta name="description" content="(.*?)">/);
          resolve({
            title: title ? title[1] : "No Title",
            description: description ? description[1] : "No Description"
          });
        })
        .catch(error => reject(error));
    });
  }
  
  if (!document.getElementById("aiPreviewOverlay")) {
    
    const overlay = document.createElement("div");
    overlay.id = "aiPreviewOverlay";
    overlay.innerHTML = `
      <div class="chatbot-box">
        <h3>🤖 Website Preview</h3>
        <p id="aiSummary">Loading summary...</p>
        <button id="continueBtn">Continue</button>
      </div>
    `;
    document.body.appendChild(overlay);
  
    const currentUrl = window.location.href;
  
   
    getPreviewContent(currentUrl)
      .then(({ title, description }) => {
        const previewText = `${title}: ${description.slice(0, 100)}...`;
        document.getElementById("aiSummary").innerText = previewText;
      })
      .catch(() => {
        document.getElementById("aiSummary").innerText = "⚠️ Could not load preview.";
      });
  
    document.getElementById("continueBtn").onclick = () => {

      document.getElementById("aiPreviewOverlay").remove();
    };
  }
  